from Crypto.Cipher import AES
import os
import sys
from secret import flag,Get_KV

def my_print(message):
    sys.stdout.write('{0}\n'.format(message))
    sys.stdout.flush()
    sys.stderr.flush()

def read_str():
    return sys.stdin.readline().strip()

def read_int():
    return int(sys.stdin.readline().strip())

def pad(msg):
    padlen = 16-len(msg)%16
    return msg + bytes([padlen])*padlen

def unpad(msg):
    if len(msg)%16 != 0:
        return False
    padlen = msg[-1]
    if padlen > 16 or padlen < 1:
        return False
    if not msg.endswith(bytes([padlen])*padlen):
        return False
    return True

def encrypt(msg):
    msg = pad(msg)
    aes = AES.new(KEY,AES.MODE_CBC,IV)
    enc = aes.encrypt(msg)
    return enc.hex()

def decrypt(enc):
    aes = AES.new(KEY,AES.MODE_CBC,IV)
    msg = aes.decrypt(enc)
    if unpad(msg):
        return msg[:-msg[-1]]
    else:
        return "verification failed!!!"

if __name__ == '__main__':
    di = '*'
    try:
        print(di*43)
        print(di*2, "Welcome to the AES encryption system!", di*2)
        my_print("Please enter your job name:")
        job_name = read_str().encode()
        KEY,IV = Get_KV(job_name)
        print(di*2, "Welcome !", di*2)
        print(di*43)         
        print(" [1]Get encrypted flag \n","[2]Encrypted information \n","[3]Decryption information\n","[4]Quit")
        print(di*43)
        while True:
            my_print("** Give your choice: ")
            choice = read_int()
            if choice == 1:
                my_print(encrypt(job_name + b':'+ flag))
                continue
            elif choice == 2:
                my_print("* Please input your message:")
                msg = read_str().encode()
                enc_info = encrypt(job_name + b':' +msg)
                my_print("* Your encrypted message:")
                my_print(enc_info)
            elif choice == 3:
                my_print("* Please input your message(hex):")
                msg = read_str()
                text_info = decrypt(bytes.fromhex(msg))
                if type(text_info)==str:
                    my_print(text_info)
                elif b'flag' in text_info:
                    my_print("Warning!!!")
                else:
                    my_print("Your decrypted message:")
                    try:
                        my_print(text_info.decode())
                    except Exception as e:
                        print("Sorry! Decode Warning!!!")
            elif choice == 4:
                my_print('Bye~')
                break
            else:
                my_print('Error!')
                break
    except:
        my_print('Error!')
        exit(0)
