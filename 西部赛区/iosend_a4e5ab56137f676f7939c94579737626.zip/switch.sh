#!/bin/bash

echo 'Welcome to the pwn_isend challenge!'
echo 'now you get a low-privilege shell, try to get the flag!'

echo -n '> '

/usr/sbin/chroot --userspec=1000:1000 / /bin/bash
