#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from sage.all import *
from secret import flag,secret
from Crypto.Util.number import *
from math import log2

class Knapsack:

    def __init__(self,n,m):
        self.n = n
        self.m = self.prem(m)
        self.A = 0
        self.B = 0
        self.k = self.prek()
        self.M = Matrix(ZZ,self.k,self.n)
        self.q = getPrime(14)

    def prek(self):
        t = pow(self.n,0.5)
        tmp = (self.n+1)*t + 1
        tmp = log2(tmp)
        k = 3
        return k

    def prem(self,m):
        tmp_m = bin(m)[2:]
        t = []
        for tmp in tmp_m:
            t.append(int(tmp))
        return t

    def get_M(self):
        for j in range(self.k):
            for i in range(self.n):
                self.M[j,i] = randint(2**9,2**11)
        print(f"M = {self.M.list()}")
    def calc_density(self):
        max_value = max(max(row) for row in self.M)
        t = self.k*log2(max_value)
        den = self.n / t
        print(den)

    def pre(self):
        self.prek()
        self.get_M()

    def enc(self):
        self.pre()
        s = []
        for j in range(self.k):
            tmp = 0
            for i in range(self.n):
                tmp += self.m[i] * self.M[j,i] %self.q
            s.append(tmp)
        print(f"s = {s}")
        self.calc_density()

    def check(self,m):
        print("Please input your key")
        key = int(input("<< "))
        if key == m:
            print(flag)

if __name__=="__main__":
    m = bytes_to_long(secret.encode())
    n = m.bit_length()
    k = Knapsack(n,m)
    k.enc()
    k.check(m)




