#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from sage.all import *
from secret import flag
from Crypto.Util.number import *
from math import log2

class Knapsack:
    def __init__(self,n,m):
        self.M = []
        self.n = n
        self.m = self.pre(m)
        self.A = 0
        self.B = 0
    def pre(self,m):
        tmp_m = bin(m)[2:]
        t = []
        for tmp in tmp_m:
            t.append(int(tmp))
        return t
    def get_M(self):
        seq = [randint(2**34,2**35) for _ in range(self.n)]
        self.M = seq
    def calc_density(self):
        t = log2(max(self.M))
        d = self.n/t
        print(d)

    def enc(self):
        self.get_M()
        self.calc_density()
        C = 0
        for t in range(len(self.m)):
            C += self.m[t] * self.M[t]
        print(f"C = {C}")
        print(f"M = {self.M}")
if __name__=="__main__":
    m = bytes_to_long(flag.encode())
    n = m.bit_length()
    k = Knapsack(n,m)
    k.enc()

# C = 231282844744
# M = [27811518167, 19889199464, 19122558731, 19966624823, 25670001067, 30690729665, 23936341812, 31011714749, 30524482330, 21737374993, 17530717152, 19140841231, 33846825616, 17334386491, 28867755886, 29354544582, 21758322019, 27261411361, 31465376167, 26145493792, 27075307455, 33514052206, 25397635665, 21970496142, 30801229475, 22405695620, 18486900933, 27071880304, 17919853256, 18072328152, 21108080920]


