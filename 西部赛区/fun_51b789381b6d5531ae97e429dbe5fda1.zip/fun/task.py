from Crypto.Cipher import AES
import random
x = 
y = 
z = 
random.seed(x + y + z)
key = random.randbytes(16)
cipher = AES.new(key, AES.MODE_EAX)
flag = b""
nonce = cipher.nonce
ciphertext, tag = cipher.encrypt_and_digest(flag)

PATH = "encrypted_flag.bin"
with open(PATH, "wb") as file_out:
    file_out.write(nonce)
    file_out.write(tag)
    file_out.write(ciphertext)

