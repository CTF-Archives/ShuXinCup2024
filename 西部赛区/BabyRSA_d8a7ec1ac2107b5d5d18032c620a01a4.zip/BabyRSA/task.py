#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from secret import flag,init
from Crypto.Util.number import *
from sage.all import *
from gmpy2 import iroot
m = bytes_to_long(flag.encode())
r = getPrime(128)

p = init
# for i in range(r-1):
#     p += next_prime(init)

# assert iroot(p,3)[1] == 1
q = getPrime(12)
# N = p*q*r
N = r**4*q
e = getPrime(17)
c = pow(m,e,N)
print(f"r = {r}")
print(f"e = {e}")
print(f"c = {c}")

# r = 287040188443069778047400125757341514899
# e = 96001
# c = 7385580281056276781497978538020227181009675544528771975750499295104237912389096731847571930273208146186326124578668216163319969575131936068848815308298035625
