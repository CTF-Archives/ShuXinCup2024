#encoding=utf-8
import string,random
from flag import secret
from gmssl import sm3

def genery_key(num):
    return_str = ''.join(random.sample(string.ascii_letters + string.digits, num))
    return return_str

def calc_sm3(message):
    tmp = [ord(i)%256 for i in message]#bytearray(message.encode()) 排查编码干扰做题更轻松
    return sm3.sm3_hash(tmp)

key = genery_key(16)

BANNER = """
only right message can get the flag ! 
"""
MENU = """
Enter your choice
[1] Create Normal Account
[2] Create Admin Account
[3] Login
[4] Exit
"""
print(BANNER)

while True:
    print(MENU)
    option = int(input('> '))
    if option == 1:
        username = genery_key(random.randint(10,12))
        password = genery_key(random.randint(10,12))
        print(f'Give You : {username} {password} {calc_sm3(key+username+password)}')  
    elif option == 2:
        print('GET OUT !!!!!!')
    elif option == 3:
        username2 = input('Enter your username > ').strip()
        if username2!=username:
            print(f'username must be {username}')
            exit(0)
        password2 = input('Enter your password > ').strip()
        if password2 == password:
            print(f'password can not be {password}')
            exit(0)
        hash_text = input('Enter your sm3_hash > ').strip()
        tmp_hash = calc_sm3(key+username2+password2)
        if hash_text == tmp_hash:
            print(secret)
        else:
            print('go away!!!')
    elif option == 4:
        print('ByeBye')
        exit(0)
    else:
        print("!!!")
