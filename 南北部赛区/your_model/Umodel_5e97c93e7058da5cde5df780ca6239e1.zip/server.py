# coding: utf-8
import io
import sys
import json
import time
import random
import base64
import joblib
import hashlib

from sklearn.pipeline import Pipeline
from sklearn.naive_bayes import MultinomialNB
from sklearn.feature_extraction.text import CountVectorizer

import numpy as np
from secret import flag
from collections import Counter


def baseModel():
    trainNum = 100
    for sentiment in datas:
        base_sentiments = [sentiment] * trainNum
        base_texts = datas[sentiment][:trainNum]

    json.dump((base_sentiments, base_texts), open('train.json', 'w'))

    model = Pipeline([
        ('vectorizer', CountVectorizer()),
        ('classifier', MultinomialNB())
    ])

    model.fit(base_texts, base_sentiments)

    joblib.dump(model, f'model.pkl')


def upload():
    model_b64 = ''
    print('Please input your model base64 (max block length: 4000): ', end='')
    while True:
        block = input()
        if block == '' or len(block) > 4000 or len(model_b64) > 1024 * 1024 * 10:
            break
        model_b64 += block
        choice = input('continue? (y/n) ')
        if choice.lower() == 'n':
            break
    try:
        model_bytes = base64.b64decode(model_b64)
        print('This img md5 is', hashlib.md5(model_bytes).hexdigest())
        model_stream = io.BytesIO(model_bytes)
        loaded_model = joblib.load(model_stream)
        models.append(loaded_model)
        print('load model success!')
    except Exception as e:
        print(repr(e))
        print("Failed to parse model!")
        sys.exit(0)
    return True


def show(test_data, test_dict, predicts, debug = False):
    right = {
        'neutral': 0,
        'positive': 0,
        'negative': 0
    }
    error = {
        'neutral': 0,
        'positive': 0,
        'negative': 0
    }

    for i in range(len(test_data)):
        text = test_data[i]
        sentiment = test_dict[text]
        predict = predicts[i]
        right[sentiment] += sentiment == predict
        error[sentiment] += sentiment != predict

    right_prob = []
    for i in right:
        right_prob += [right[i] / (right[i] + error[i])]

    return right_prob

def random_data_predicts(nums=None):
    test_data = []
    test_dict = {}
    if not nums:
        nums = [300, 300, 300]
    for sentiment, num in zip(sentiments, nums):
        data = random.sample(datas[sentiment], num)
        test_data += data
        for i in data:
            test_dict[i] = sentiment

    random.shuffle(test_data)

    mod_predicts = []
    for mod in models:
        mod_predicts.append(mod.predict(test_data))

    predicts = []
    for j in range(len(test_data)):
        my_list = [mod_predicts[i][j] for i in range(len(mod_predicts))]
        counter = Counter(my_list)
        predict = counter.most_common(1)[0][0]
        predicts.append(predict)

    return test_data, test_dict, predicts


def challenge(num = 30):
    prob = np.zeros(3)
    for i in range(num):
        info = random_data_predicts()
        prob += show(*info)
    prob /= num

    if prob[0] < 0.6 or prob[1] < 0.8 or prob[2] < 0.7:
        print('Subpar Prediction Precision. Try again!')
        print(prob)
    else:
        print('Congratulations! You have passed the challenge!')
        print(f'Here is the flag: {flag}')
        sys.exit(0)


def exit():
    print('bye~')
    sys.exit(0)


def menu():
    print('1. Upload model')
    print('2. Start challenge')
    print('3. Exit')


def init():
    global models, datas

    model = joblib.load('model.pkl')
    models.append(model)

    with open('./data.json', 'r') as f:
        datas = json.load(f)


if __name__ == '__main__':
    sentiments = ('neutral', 'positive', 'negative')
    models = []
    init()
    func = [baseModel, upload, challenge, exit]
    while True:
        menu()
        choice = int(input())
        func[choice]()